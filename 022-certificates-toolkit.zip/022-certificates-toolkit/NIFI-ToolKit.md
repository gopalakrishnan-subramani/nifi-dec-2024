sudo apt-get install openjdk-11-jdk

export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
java -version


wget https://downloads.apache.org/nifi/1.28.1/nifi-toolkit-1.28.1-bin.zip

unzip nifi-toolkit-1.28.1-bin.zip


sudo mv ./nifi-toolkit-1.28.1 /opt/nifi-toolkit


ls /opt/nifi-toolkit


/opt/nifi-toolkit/bin/tls-toolkit.sh standalone --hostnames 'nifi,nifi[0-5]' --clientCertDn 'CN=admin,OU=NiFi' --subjectAlternativeNames 'localhost,0.0.0.0,nifi0.nifi.training.sh,nifi1.nifi.training.sh,nifi2.nifi.training.sh,nifi3.nifi.training.sh,nifi4.nifi.training.sh,nifi.training.sh' --keyStorePassword gP4sX7v1zRkQ9LmNw --trustStorePassword gP4sX7v1zRkQ9LmNw --outputDirectory ./certs 


===

Convert JKS to PKCS12:
 
keytool -importkeystore \
-srckeystore ./certs/nifi/keystore.jks \
-destkeystore ./certs/nifi/keystore.p12 \
-srcstoretype JKS \
-deststoretype PKCS12


 
openssl pkcs12 -in ./certs/nifi/keystore.p12 -nokeys -out ./certs/nifi/nginx-cert.crt
openssl pkcs12 -in ./certs/nifi/keystore.p12 -nocerts -out ./certs/nifi/nginx-key.pem


 ==


# Generate private key for admin2
openssl genrsa -out ./nifi-users/admin2.key 2048

# Create CSR (Certificate Signing Request) for admin2
openssl req -new -key ./nifi-users/admin2.key -out ./nifi-users/admin2.csr \
-subj "/C=IN/ST=TN/L=CHE/O=ExOrg2/OU=users/CN=admin2"

# Sign admin2 CSR with nifi-ca
openssl x509 -req -in ./nifi-users/admin2.csr -CA ./certs/nifi-cert.pem -CAkey ./certs/nifi-key.key -CAcreateserial \
-out ./nifi-users/admin2.crt -days 365 -sha256

# Export to PKCS12 for Firefox import
openssl pkcs12 -export -inkey ./nifi-users/admin2.key -in ./nifi-users/admin2.crt -certfile ./certs/nifi-cert.pem \
-out ./nifi-users/admin2.p12

export password: firefox123

Go to firefox, Settings -> Certificate, import admin2.p12
==
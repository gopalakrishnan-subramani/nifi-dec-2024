import com.sun.net.httpserver.HttpsServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpsConfigurator;
import com.sun.net.httpserver.*;
import javax.net.ssl.*;
import java.io.*;
import java.net.InetSocketAddress;
import javax.net.ssl.*;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.security.KeyStore;
import java.security.cert.X509Certificate;

// javac HelloWorldKeyTrustStore.java
// java HelloWorldKeyTrustStore

public class HelloWorldKeyTrustStore {

    public static void main(String[] args) throws Exception {

        System.out.println("Arg length " + args.length);

        System.out.println("Arg length " + String.join(":", args));

        int port = 8443;
        String keystorePath = args.length == 1? args[0]: "./le-nifi/nifi.training.sh.keystore";  // Path to PKCS12 keystore
        String keystorePassword = "gP4sX7v1zRkQ9LmNw";
        String keyPassword = "gP4sX7v1zRkQ9LmNw";
        String keystoreType = "PKCS12";  

        String truststorePath = "./truststore/nifi.traning.sh.truststore";   // Truststore for client cert validation
        String truststorePassword = "gP4sX7v1zRkQ9LmNw";  // Password for the truststore
        String truststoreType = "PKCS12";  


        System.out.println("keystore path " + keystorePath);

        // Load the keystore
        KeyStore keystore = KeyStore.getInstance(keystoreType);
        try (FileInputStream fis = new FileInputStream(keystorePath)) {
            keystore.load(fis, keystorePassword.toCharArray());
        }

        // Initialize Key Manager (for server cert)
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        kmf.init(keystore, keyPassword.toCharArray());



        // Load the truststore (to verify client certificates)
        KeyStore truststore = KeyStore.getInstance(truststoreType);
        try (FileInputStream fis = new FileInputStream(truststorePath)) {
            truststore.load(fis, truststorePassword.toCharArray());
        }

        // Initialize Trust Manager (for client cert verification)
        TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
        tmf.init(truststore);


        // Set up SSL context without TrustManager (no client auth)
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);  // <-- No TrustManager (removes client auth)

        // Create HTTPS server
        HttpsServer server = HttpsServer.create(new InetSocketAddress(port), 0);
        // server.setHttpsConfigurator(new HttpsConfigurator(sslContext));

        SSLServerSocketFactory ssf = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        System.out.println("*****");
        for (String s : ssf.getSupportedCipherSuites()) {
            System.out.println(s);
        }

        System.out.println("*****");
        server.setHttpsConfigurator(new HttpsConfigurator(sslContext) {
            public void configure(HttpsParameters params) {
                try {
                    System.out.println("Configuring TLS Mutual Auth");
                    SSLContext c = getSSLContext();
                    SSLEngine engine = c.createSSLEngine();
                    
                    params.setNeedClientAuth(true);  // Enforce Client Authentication (mTLS)
                    //params.setCipherSuites(engine.getEnabledCipherSuites());
                    //params.setCipherSuites(new String[] {"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"});

                    // params.setCipherSuites(new String[] {
                    //     "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
                    //     "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
                    //     "TLS_RSA_WITH_AES_256_CBC_SHA256",
                    //     "TLS_RSA_WITH_AES_128_CBC_SHA"
                    // });

                     params.setCipherSuites(ssf.getSupportedCipherSuites());

                    params.setProtocols(engine.getEnabledProtocols());
                } catch (Exception ex) {
                    System.out.println("***********");
                    ex.printStackTrace();
                }
            }
        });

        // Create endpoint
        server.createContext("/hello", new HelloHandler());

         server.setExecutor(null); // Default executor
        server.start();

        System.out.println("HTTPS Server started at https://your-cert-domain:" + port + "/hello");
    }

    static class HelloHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws java.io.IOException {
            SSLSession sslSession = ((HttpsExchange) exchange).getSSLSession();
            X509Certificate[] clientCerts = (X509Certificate[]) sslSession.getPeerCertificates();

            String clientInfo = "Unknown Client";
            if (clientCerts != null && clientCerts.length > 0) {
                X509Certificate clientCert = clientCerts[0];
                clientInfo = clientCert.getSubjectX500Principal().getName();
            }

            String response = "Hello, " + clientInfo;
            exchange.sendResponseHeaders(200, response.getBytes().length);
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }
}

export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

/opt/nifi-toolkit/bin/tls-toolkit.sh standalone \
  -n 'nifi.training.sh' \
  --certificateAuthorityDirectory  ./ca-certs \
  --certificateDirectory ./certs \
  --keyStorePassword gP4sX7v1zRkQ9LmNw \
  --trustStorePassword gP4sX7v1zRkQ9LmNw \
  -o ./gen-certs


https://blog.ordina-jworks.io/security/2019/08/14/Using-Lets-Encrypt-Certificates-In-Java.html


openssl pkcs12 -export \
	 -in /etc/letsencrypt/live/mydomain.be/cert.pem \
	 -inkey /etc/letsencrypt/live/mydomain.be/privkey.pem \
	 -out /tmp/mydomain.be.p12 \
	 -name mydomain.be \
	 -CAfile /etc/letsencrypt/live/mydomain.be/fullchain.pem \
	 -caname "Let's Encrypt Authority X3" \
	 -password pass:changeit


openssl pkcs12 -export \
	 -in ./cert1.pem \
	 -inkey ./privkey1.pem \
	 -out ./nifi.training.sh.p12 \
	 -name nifi.training.sh \
	 -CAfile ./fullchain1.pem \
	 -caname "Let's Encrypt Authority X3" \
	 -password pass:gP4sX7v1zRkQ9LmNw

note: pass: is a keyword


keytool -importkeystore \
	-deststorepass gP4sX7v1zRkQ9LmNw \
	-destkeypass gP4sX7v1zRkQ9LmNw \
	-deststoretype pkcs12 \
	-srckeystore nifi.training.sh.p12 \
	-srcstoretype PKCS12 \
	-srcstorepass gP4sX7v1zRkQ9LmNw \
	-destkeystore ./nifi.training.sh.keystore \
	-alias nifi.training.sh

InsPECT

keytool -list -v \
-keystore ./nifi.training.sh.keystore \
-storetype PKCS12 \
-storepass gP4sX7v1zRkQ9LmNw


now import/add up lets encrypt root to the keystore

ls -ls ./nifi.training.sh.keystore 

keytool -import -trustcacerts \
-keystore ./nifi.training.sh.keystore \
-storetype PKCS12 \
-storepass gP4sX7v1zRkQ9LmNw \
-alias letsencrypt \
-file isrgrootx1.pem


ls -ls ./nifi.training.sh.keystore 


# Verify the import

keytool -list -v \
-keystore ./nifi.training.sh.keystore \
-storetype PKCS12 \
-storepass gP4sX7v1zRkQ9LmNw | grep letsencrypt
 


InsPECT 2 certs must present

keytool -list -v \
-keystore ./nifi.training.sh.keystore \
-storetype PKCS12 \
-storepass gP4sX7v1zRkQ9LmNw


==================
# Generate the CA private key
openssl genrsa -out ./nifi-ca.key 4096

# Create a self-signed CA certificate
openssl req -x509 -new -nodes -key ./nifi-ca.key -sha256 -days 365 -out ./nifi-ca.crt \
-subj "/C=IN/ST=KA/L=BLR/O=ExOrg/OU=users/CN=nifi-ca"



keytool -import -trustcacerts \
  -alias nifi-ca \
  -file ./nifi-ca.crt \
  -keystore ./nifi.traning.sh.truststore.p12 \
  -storetype PKCS12  \
  -storepass gP4sX7v1zRkQ9LmNw

# Generate private key for admin1
openssl genrsa -out ./admin1.key 2048

# Create CSR (Certificate Signing Request) for admin1
openssl req -new -key ./admin1.key -out ./admin1.csr \
-subj "/C=IN/ST=KA/L=BLR/O=ExOrg/OU=users/CN=admin1"

# Sign admin1 CSR with nifi-ca
openssl x509 -req -in ./admin1.csr -CA ./nifi-ca.crt -CAkey ./nifi-ca.key -CAcreateserial \
-out ./admin1.crt -days 365 -sha256

# Export to PKCS12 for Firefox import
openssl pkcs12 -export -inkey ./admin1.key -in ./admin1.crt -certfile ./nifi-ca.crt \
-out ./admin1.p12




================

Turotial 2

A trust store verification for clients



openssl req -x509 -nodes -newkey rsa:4096 \
  -keyout ./nifi-ca.key \
  -out ./nifi-ca.crt \
  -days 365 \
  -subj "/C=US/ST=CA/L=SF/O=NiFi/OU=Security/CN=nifi-ca"


keytool -import -trustcacerts \
  -alias nifi-ca \
  -file ./nifi-ca.crt \
  -keystore ./nifi.traning.sh.truststore.p12 \
  -storetype PKCS12  \
  -storepass gP4sX7v1zRkQ9LmNw

==============

client docker firefox certificates
====

openssl req -new -newkey rsa:4096 -nodes \
  -keyout ./host-firefox.key \
  -out ./host-firefox.csr \
  -subj "/C=US/ST=CA/L=SF/O=NiFi/OU=Client/CN=host-firefox"

  openssl x509 -req \
  -in ./host-firefox.csr \
  -CA ./nifi-ca.crt \
  -CAkey ./nifi-ca.key \
  -CAcreateserial \
  -out ./host-firefox.crt \
  -days 365



  Bundle Client Certificates (For Browser Use)
Docker-Firefox (PKCS12):


openssl pkcs12 -export \
  -out ./host-firefox.p12 \
  -inkey ./host-firefox.key \
  -in ./host-firefox.crt \
  -certfile ./nifi-ca.crt \
  -password pass:firefox123


openssl req -new -newkey rsa:4096 -nodes \
  -keyout ./docker-firefox.key \
  -out ./docker-firefox.csr \
  -subj "/C=US/ST=CA/L=SF/O=NiFi/OU=Client/CN=docker-firefox"

openssl x509 -req \
  -in ./docker-firefox.csr \
  -CA ./nifi-ca.crt \
  -CAkey ./nifi-ca.key \
  -CAcreateserial \
  -out ./docker-firefox.crt \
  -days 365


openssl pkcs12 -export \
  -out ./docker-firefox.p12 \
  -inkey ./docker-firefox.key \
  -in ./docker-firefox.crt \
  -certfile ./nifi-ca.crt \
  -password pass:firefox123

import .p12 into firefox

CURL Client

openssl req -new -newkey rsa:4096 -nodes \
  -keyout ./curl-client.key \
  -out ./curl-client.csr \
  -subj "/C=US/ST=CA/L=SF/O=NiFi/OU=Client/CN=curl-client"


openssl x509 -req \
  -in ./curl-client.csr \
  -CA ./nifi-ca.crt \
  -CAkey ./nifi-ca.key \
  -CAcreateserial \
  -out ./curl-client.crt \
  -days 365

cat ./curl-client.crt ./curl-client.key > ./curl-client.pem


curl --cert curl-client.pem \
     --cacert nifi-ca.crt \
     https://nifi0.nifi.training.sh:8443/nifi/




keytool -list -v -keystore /home/gs/nifi/nifi-dec-2024/020-certification/nifi0.nifi.training.sh.keystore -storetype PKCS12 -storepass gP4sX7v1zRkQ9LmNw



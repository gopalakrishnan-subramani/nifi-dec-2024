\c
 
-- Create 'nifidb' database if it doesn't exist
SELECT 'CREATE DATABASE nifidb'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'nifidb')\gexec;


-- Create user if it doesn't exist
DO
$$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'admin') THEN
      CREATE ROLE admin WITH LOGIN PASSWORD 'supersecret1';
      ALTER ROLE admin WITH SUPERUSER CREATEDB CREATEROLE;
   END IF;
END
$$;

-- Grant privileges to the user on nifidb
GRANT ALL PRIVILEGES ON DATABASE nifidb TO admin;


-- Connect to nifidb
\c nifidb;
-- Create table if it doesn't exist
CREATE TABLE IF NOT EXISTS sensor_data (
    id SERIAL PRIMARY KEY,
    sensor_name VARCHAR(50),
    value DOUBLE PRECISION,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Grant all privileges on the table to the user
GRANT ALL PRIVILEGES ON TABLE sensor_data TO admin;

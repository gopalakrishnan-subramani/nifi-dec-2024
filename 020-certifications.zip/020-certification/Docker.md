https://github.com/apache/nifi/blob/main/nifi-docker/dockerhub/sh/secure.sh
https://github.com/apache/nifi/blob/main/nifi-docker/dockerhub/sh/start.sh



docker  build --no-cache  --build-arg NIFI_VERSION=1.28.0 --tag training/nifi-custom:0.0.15  ./



docker compose exec -it nifi0 bash

ls /opt/nifi/certs/

ls /opt/nifi/nifi-current/lib

ls /opt/nifi/nifi-current/lib | grep netsa

cat /opt/nifi/nifi-current/conf/nifi.properties | grep nifi.nar.library.directory



direct nifi
https://nifi0.nifi.training.sh:8443/nifi/


nginx
https://nifi.training.sh/nifi/



export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

GENERATE PKCS file with all together

openssl pkcs12 -export \
	 -in ./le/cert1.pem \
	 -inkey ./le/privkey1.pem \
	 -out ./le-nifi/nifi.training.sh.p12 \
	 -name nifi.training.sh \
	 -CAfile ./le/fullchain1.pem \
	 -caname "Let's Encrypt Authority X3" \
	 -password pass:gP4sX7v1zRkQ9LmNw

note: pass: is a keyword

# CREATE KEYSTORE file for HTTPS REQUEST. 
# PARTIAL, does not include ROOT CA LETSCRYPT certificate
# SOME ROOT CAs certificates are come along OS, Browser, JAVA SDK. 
# GOOD to include ROOT CA, as part of our system, because we cann't control if someone removed those certificates from Browsers, OS.

keytool -importkeystore \
	-deststorepass gP4sX7v1zRkQ9LmNw \
	-destkeypass gP4sX7v1zRkQ9LmNw \
	-deststoretype pkcs12 \
	-srckeystore ./le-nifi/nifi.training.sh.p12 \
	-srcstoretype PKCS12 \
	-srcstorepass gP4sX7v1zRkQ9LmNw \
	-destkeystore ./le-nifi/nifi.training.sh.keystore \
	-alias nifi.training.sh

InsPECT

 

keytool -list -v \
-keystore ./le-nifi/nifi.training.sh.keystore \
-storetype PKCS12 \
-storepass gP4sX7v1zRkQ9LmNw

Note. we dont have letscrypt ca cert here

 keytool -list -v -keystore ./le-nifi/nifi.training.sh.keystore -storetype PKCS12 -storepass gP4sX7v1zRkQ9LmNw | grep nifi

keytool -list -v -keystore ./le-nifi/nifi.training.sh.keystore -storetype PKCS12 -storepass gP4sX7v1zRkQ9LmNw | grep letsencrypt

now import/add up lets encrypt root ca certificate to the keystore, check cert size without ca root certification

ls -ls ./le-nifi/nifi.training.sh.keystore 

append to existing keystore file..

keytool -import -trustcacerts \
-keystore ./le-nifi/nifi.training.sh.keystore \
-storetype PKCS12 \
-storepass gP4sX7v1zRkQ9LmNw \
-alias letsencrypt \
-file ./le/isrgrootx1.pem


ls -ls ./le-nifi/nifi.training.sh.keystore 


# Verify the import

keytool -list -v \
-keystore ./le-nifi/nifi.training.sh.keystore \
-storetype PKCS12 \
-storepass gP4sX7v1zRkQ9LmNw | grep letsencrypt
 

InsPECT 2 certs must present

keytool -list -v \
-keystore ./le-nifi/nifi.training.sh.keystore \
-storetype PKCS12 \
-storepass gP4sX7v1zRkQ9LmNw

==========

```
sudo nano /etc/hosts

```

add three domains
```
127.0.0.1    nifi.training.sh
127.0.0.1    nifi0.nifi.training.sh
127.0.0.1    dec2024.training.sh 

127.0.0.1    fake.training.sh
```


javac HelloWorldKeyStore.java

java HelloWorldKeyStore  java HelloWorldKeyStore ./le-nifi/nifi.training.sh.keystore

open browser.

check below 

https://nifi.training.sh:8443/hello

https://nifi0.nifi.training.sh:8443/hello

this should not work for letsenpryt, but work for freecert
https://dec2024.training.sh:8443/hello

this should not work for both letsenpryt and freecert

https://fake.training.sh:8443/hello


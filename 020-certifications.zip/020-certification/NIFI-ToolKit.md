sudo apt-get install openjdk-11-jdk

export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH
java -version


wget https://downloads.apache.org/nifi/1.28.1/nifi-toolkit-1.28.1-bin.zip

unzip nifi-toolkit-1.28.1-bin.zip


sudo mv ./nifi-toolkit-1.28.1 /opt/nifi-toolkit


ls /opt/nifi-toolkit


/opt/nifi-toolkit/bin/tls-toolkit.sh standalone --hostnames 'nifi,nifi[0-5]' --clientCertDn 'CN=admin,OU=NiFi' --subjectAlternativeNames 'localhost,0.0.0.0,nifi0.nifi.training.sh,nifi1.nifi.training.sh,nifi2.nifi.training.sh,nifi3.nifi.training.sh,nifi4.nifi.training.sh,nifi.training.sh' --keyStorePassword gP4sX7v1zRkQ9LmNw --trustStorePassword gP4sX7v1zRkQ9LmNw --outputDirectory ./certs


openssl pkcs12 -export -out nifi.p12 -inkey nifi.key -in nifi.pem -name nifi-key 
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk-amd64
export PATH=$JAVA_HOME/bin:$PATH

GENERATE PKCS file with all together


openssl pkcs12 -export \
  -in ./zs/certificate.crt \
  -inkey ./zs/private.key \
  -certfile ./zs/ca_bundle.crt \
  -out ./zs-nifi/nifi.training.sh.p12 \
  -name nifi.training.sh \
  -password pass:gP4sX7v1zRkQ9LmNw

 
note: pass: is a keyword

# CREATE KEYSTORE file for HTTPS REQUEST. 
# PARTIAL, does not include ROOT CA LETSCRYPT certificate
# SOME ROOT CAs certificates are come along OS, Browser, JAVA SDK. 
# GOOD to include ROOT CA, as part of our system, because we cann't control if someone removed those certificates from Browsers, OS.

keytool -importkeystore \
	-deststorepass gP4sX7v1zRkQ9LmNw \
	-destkeypass gP4sX7v1zRkQ9LmNw \
	-deststoretype pkcs12 \
	-srckeystore ./zs-nifi/nifi.training.sh.p12 \
	-srcstoretype PKCS12 \
	-srcstorepass gP4sX7v1zRkQ9LmNw \
	-destkeystore ./zs-nifi/nifi.training.sh.keystore \
	-alias nifi.training.sh

InsPECT

 
 

==========

```
sudo nano /etc/hosts

```

add three domains
```
127.0.0.1    nifi.training.sh
127.0.0.1    nifi0.nifi.training.sh
127.0.0.1    dec2024.training.sh 

127.0.0.1    fake.training.sh
```


javac HelloWorldKeyStore.java

java HelloWorldKeyStore ./zs-nifi/nifi.training.sh.keystore

open browser.

check below 

should work
https://dec2024.training.sh:8443/hello

this should not work for below

https://nifi.training.sh:8443/hello

https://nifi0.nifi.training.sh:8443/hello

https://fake.training.sh:8443/hello


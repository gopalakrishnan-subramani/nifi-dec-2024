import com.sun.net.httpserver.HttpsServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpsConfigurator;

import javax.net.ssl.*;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.security.KeyStore;

// javac HelloWorldKeyStore.java
// java HelloWorldKeyStore

public class HelloWorldKeyStore {

    public static void main(String[] args) throws Exception {

        System.out.println("Arg length " + args.length);

        System.out.println("Arg length " + String.join(":", args));

        int port = 8443;
        String keystorePath = args.length == 1? args[0]: "./le-nifi/nifi.training.sh.keystore";  // Path to PKCS12 keystore
        String keystorePassword = "gP4sX7v1zRkQ9LmNw";
        String keyPassword = "gP4sX7v1zRkQ9LmNw";
        String keystoreType = "PKCS12";  

        System.out.println("keystore path " + keystorePath);

        // Load the keystore
        KeyStore keystore = KeyStore.getInstance(keystoreType);
        try (FileInputStream fis = new FileInputStream(keystorePath)) {
            keystore.load(fis, keystorePassword.toCharArray());
        }

        // Initialize Key Manager (for server cert)
        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        kmf.init(keystore, keyPassword.toCharArray());

        // Set up SSL context without TrustManager (no client auth)
        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), null, null);  // <-- No TrustManager (removes client auth)

        // Create HTTPS server
        HttpsServer server = HttpsServer.create(new InetSocketAddress(port), 0);
        server.setHttpsConfigurator(new HttpsConfigurator(sslContext));

        // Create endpoint
        server.createContext("/hello", new HelloHandler());
        server.start();

        System.out.println("HTTPS Server started at https://your-cert-domain:" + port + "/hello");
    }

    static class HelloHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws java.io.IOException {
            String response = "Hello, World over HTTPS!";
            exchange.sendResponseHeaders(200, response.length());
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }
}

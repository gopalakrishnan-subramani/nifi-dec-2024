# Generate the CA private key
openssl genrsa -out ./nifi-ca/nifi-ca.key 4096

# Create a self-signed CA certificate
openssl req -x509 -new -nodes -key ./nifi-ca/nifi-ca.key -sha256 -days 365 -out ./nifi-ca/nifi-ca.crt \
-subj "/C=IN/ST=KA/L=BLR/O=ExOrg/OU=users/CN=nifi-ca"


cat ./nifi-ca/nifi-ca.crt ./nifi-ca/nifi-ca.key > ./nifi-ca/nifi-ca.pem


==========
nifi server certificates

openssl genrsa -out nifi-server.key 2048

openssl req -new -key nifi-server.key -out nifi-server.csr

openssl x509 -req -in nifi-server.csr -CA nifi-ca.crt -CAkey nifi-ca.key -CAcreateserial -out nifi-server.crt -days 365

keytool -importkeystore -srckeystore nifi-server.p12 -srcstoretype PKCS12 -destkeystore nifi-server.jks -deststoretype PKCS12




==========

====================
nginx certificate for proxy pass

openssl req -new -newkey rsa:2048 -nodes -keyout ./nginx/nginx-client.key -out ./nginx/nginx-client.csr -subj "/C=IN/ST=KA/L=BLR/O=ExOrg/OU=users/CN=nginx"

openssl x509 -req -in ./nginx/nginx-client.csr -CA ./nifi-ca/nifi-ca.pem -CAkey ./nifi-ca/nifi-ca.key -CAcreateserial -out ./nginx/nginx-client.crt -days 365

openssl x509 -text -noout -in ./nginx/nginx-client.crt

cat ./nginx/nginx-client.crt ./nginx/nginx-client.key > ./nginx/nginx-client.pem

cat ./nifi-ca/nifi-ca.crt ./nginx/nginx-client.crt ./nginx/nginx-client.key > ./nginx/nginx-client.pem
 
 
=================

==============

keytool -import -trustcacerts \
  -alias nifi-ca \
  -file  ./nifi-ca/nifi-ca.crt \
  -keystore ./truststore/nifi.traning.sh.truststore \
  -storetype PKCS12  \
  -storepass gP4sX7v1zRkQ9LmNw
 

 Need to type yes and ENTER to generate certificate.


=======

 java HelloWorldKeyTrustStore ./zs-nifi/nifi.training.sh.keystore


 java  -Djavax.net.debug=all -Djava.util.logging.config.file=logging.properties HelloWorldKeyTrustStore

 ==


# Generate private key for admin1
openssl genrsa -out ./nifi-users/admin1.key 2048

# Create CSR (Certificate Signing Request) for admin1
openssl req -new -key ./nifi-users/admin1.key -out ./nifi-users/admin1.csr \
-subj "/C=IN/ST=KA/L=BLR/O=ExOrg/OU=users/CN=admin1"

# Sign admin1 CSR with nifi-ca
openssl x509 -req -in ./nifi-users/admin1.csr -CA ./nifi-ca/nifi-ca.crt -CAkey ./nifi-ca/nifi-ca.key -CAcreateserial \
-out ./nifi-users/admin1.crt -days 365 -sha256

# Export to PKCS12 for Firefox import
openssl pkcs12 -export -inkey ./nifi-users/admin1.key -in ./nifi-users/admin1.crt -certfile ./nifi-ca/nifi-ca.crt \
-out ./nifi-users/admin1.p12

export password: firefox123

Go to firefox, Settings -> Certificate, import admin1.p12
==
curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64
sudo install minikube-linux-amd64 /usr/local/bin/minikube && rm minikube-linux-amd64


minikube start

kubectl get po -A

minikube kubectl -- get po -A

minikube dashboard

=====

Install kubectl

   curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"



   curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl.sha256"


echo "$(cat kubectl.sha256)  kubectl" | sha256sum --check

install

sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

check all well


kubectl version --client

kubectl version --client --output=yaml

=====

install kind for local development management

# For AMD64 / x86_64
[ $(uname -m) = x86_64 ] && curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.26.0/kind-linux-amd64

chmod +x ./kind
sudo mv ./kind /usr/local/bin/kind



=========

kubectl create deployment hello-minikube --image=kicbase/echo-server:1.0

kubectl expose deployment hello-minikube --type=NodePort --port=8080

kubectl get services hello-minikube

minikube service hello-minikube

kubectl port-forward service/hello-minikube 17080:8080

on host machine

http://localhost:17080/.

====

kubectl delete deployment hello-minikube


kubectl delete service hello-minikube

kubectl get deployment
kubectl get services
====

cluster management command

minikube pause

minikube unpause

minikube stop

minikube config set memory 9001

minikube addons list

minikube start -p aged --kubernetes-version=v1.16.1

minikube delete --all


----

cd nifi-docker/


docker build -t training/nifid:0.0.1 .

cd ..

-----

cd node-hello

docker build -t training/node-hello:latest .

cd ..

------

a structure looks like below

k8s/
  01-zookeeper.yaml
  02-kafka.yaml
  03-node-hello.yaml
  04-nifi.yaml
  05-nginx.yaml
  06-nginx-configmap.yaml


```
cd k8s
# From the 'k8s' folder:
kubectl apply -f 01-zookeeper.yaml
kubectl apply -f 02-kafka.yaml
kubectl apply -f 03-node-hello.yaml
kubectl apply -f 04-nifi.yaml
kubectl apply -f 06-nginx-configmap.yaml
kubectl apply -f 05-nginx.yaml
```

or to run all yaml together

```
kubectl apply -f .
```

```
kubectl get pods
kubectl get svc
```


```
kubectl logs <pod-name>

kubectl logs  node-hello

kubectl describe node-hello
```


validatation

```
kubectl exec -it <any-pod> -- curl node-hello:3000
```


====

by default kube will pull image from docker hub.
but we don't want to put our images into dokcer hub.

we have two images..


- training/node-hello:latest
- training/nifid:0.0.1

now, run docker in localhost for kube to fetch images


docker run -d -p 5000:5000 --name local-registry registry:2

docker tag training/node-hello:latest localhost:5000/training/node-hello:latest
docker push localhost:5000/training/node-hello:latest


--

docker tag training/nifid:0.0.1 localhost:5000/training/nifid:0.0.1
docker push localhost:5000/training/nifid:0.0.1

===

now you fix the pods rightly

first delete old pods

kubectl delete -f 03-node-hello.yaml
kubectl delete -f 04-nifi.yaml


then run the pods again

kubectl apply -f 03-node-hello.yaml
kubectl apply -f 04-nifi.yaml

or simple add labels, in metadata, 

like below.

labels:
    app: node-hello
    version: "2" # we made change
====

easy approach, ask minikube ot use its own docker

minikube start
eval $(minikube docker-env)


minikube start
minikube addons enable registry

# Forward local port 5000 to the registry’s port 80 in the kube-system namespace
kubectl port-forward --namespace kube-system service/registry 5000:80 &


# Tag your existing image so it points to the Minikube registry
docker tag training/node-hello:latest localhost:5000/training/node-hello:latest

# Push it
docker push localhost:5000/training/node-hello:latest


kubectl delete -f 03-node-hello.yaml
kubectl apply -f 03-node-hello.yaml
===

# Tag your existing image so it points to the Minikube registry
docker tag training/nifid:0.0.1 localhost:5000/training/nifid:0.0.1

# Push it
docker push localhost:5000/training/nifid:0.0.1

kubectl delete -f 04-nifi.yaml
kubectl apply -f  04-nifi.yaml


---

validate the setup again

kubectl get pods
kubectl get svc

kubectl exec -it  nifi -- curl node-hello:3000

kubectl exec -it  nifi -- curl nifi:8080/nifi

kubectl exec -it  nifi -- bash


---
changed 04-nifi.yaml to nodeport, default it was clusterip
--
minikube ip  

kubectl get nodes -o wide


http://192.168.49.2:30080/nifi

http://localhost:30080/nifi
--

firefox in docker

kubectl apply -f 07-firefox.yaml

minikube ip


http://192.168.49.2:30081/

access firefox runs inside docker

now access nifi:8080 from inside firefox

http://nifi:8080/nifi/


===============

echo "my-fake-keystore-cert" > fake-keystore.jks

echo "my-fake-keystore-pass" > fake-keystore-password.txt

--
# Create ConfigMap for the cert (truststore)
kubectl create configmap node-fake-keystore --from-file=fake-keystore.jks

# Create Secret for the keystore password
kubectl create secret generic node-fake-keystore-pass --from-file=fake-keystore-password.txt


kubectl apply -f 008-node-config-test.yaml


remember, this pods runs for an hour only. look into command, sleep 3600 statment in yaml

kubectl exec -it 008-node-config-test -- /bin/sh




ls /certs
cat /certs/truststore.jks  # Should display 'fake-truststore-data'

ls /secrets
cat /secrets/keystore-password.txt  # Should display 'keystore-password'

echo $TRUSTSTORE_PATH  # /certs/truststore.jks
echo $KEYSTORE_PASS_PATH  # /secrets/keystore-password.txt
cat $KEYSTORE_PASS_PATH  # Reads password file content



----

kubectl get secrets

kubectl get configmap


kubectl describe configmap  <config-name>




kubectl edit configmap <configmap-name>


kubectl create configmap <configmap-name> --from-file=path/to/new-file --dry-run=client -o yaml | kubectl apply -f -


kubectl delete configmap <configmap-name>

update node js keystore

kubectl create configmap node-truststore --from-file=truststore.jks --dry-run=client -o yaml | kubectl apply -f -


--

kubectl get all --all-namespaces
kubectl get configmap,secret


kubectl describe secret <secrect-name>

kubectl get secret node-fake-keystore-pass -o yaml

```
apiVersion: v1
data:
  fake-keystore-password.txt: bXktZmFrZS1rZXlzdG9yZS1wYXNzCg==
kind: Secret
metadata:
  creationTimestamp: "2024-12-25T08:50:36Z"
  name: node-fake-keystore-pass
  namespace: default
  resourceVersion: "10499"
  uid: a1ff0a8c-a947-4aef-88af-a5b1402fe768
type: Opaque
```


 the file name fake-keystore-password.txt is the key

kubectl get secret <secret-name> -o jsonpath="{.data.<key-name>}" | base64 --decode


kubectl get secret node-fake-keystore-pass -o jsonpath="{.data.fake-keystore-password.txt}" | base64 --decode

---

echo -n "my-secret-password" | base64
kubectl create secret generic db-password --from-literal=password=my-secret-password
kubectl get secret db-password -o yaml
kubectl get secret db-password -o jsonpath="{.data.password}" | base64 --decode

-----
